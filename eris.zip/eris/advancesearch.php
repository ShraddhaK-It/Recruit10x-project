<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Search</title>
    
    <!-- Include AOS CSS -->
    <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
    
    <!-- Include Swiper CSS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@9/swiper-bundle.min.css">
    <style>
        body {
           
            font-family: 'Poppins', sans-serif;
            color: #fff;
        }
        #content {
            min-height: 500px;
            padding: 40px 0;
        }
        .panel {
            background: rgba(255, 255, 255, 0.1);
            padding: 30px;
			margin-left :50px;
			margin-right :10px;
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .panel-header {
            text-align: center;
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .panel-body label {
            font-size: 20px;
            font-weight: bold;
        }
        .panel-body input, .panel-body select {
            font-size: 16px;
            border: none;
            border-radius: 8px;
            padding: 10px;
            width: 100%;
        }
        .panel-body .row {
            margin-bottom: 20px;
        }
        .btn-success {
            width: 100%;
            font-size: 20px;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background: #ff5e62;
            background: linear-gradient(135deg, #ff5e62, #ff9966);
            color: white;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
            transition: background 0.3s ease;
        }
        .btn-success:hover {
            background: linear-gradient(135deg, #ff9966, #ff5e62);
        }
    </style>
</head>
<body>
<form action="index.php?q=result&searchfor=advancesearch" method="POST">
    <section id="content">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="panel">
                        <div class="panel-header">Advanced Job Search</div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <label for="search">SEARCH:</label>
                                    <input type="text" class="form-control" name="SEARCH" placeholder="Search For">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <label for="company">COMPANY:</label>
                                    <select class="form-control" name="COMPANY">
                                        <option value="">All</option>
                                        <?php
                                            $sql = "SELECT * FROM tblcompany";
                                            $mydb->setQuery($sql);
                                            $res = $mydb->loadResultList();
                                            foreach ($res as $row) {
                                                echo '<option>' . htmlspecialchars($row->COMPANYNAME) . '</option>';
                                            }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <label for="category">FUNCTION:</label>
                                    <select class="form-control" name="CATEGORY">
                                        <option value="">All</option>
                                        <?php
                                            $sql = "SELECT * FROM tblcategory";
                                            $mydb->setQuery($sql);
                                            $res = $mydb->loadResultList();
                                            foreach ($res as $row) {
                                                echo '<option>' . htmlspecialchars($row->CATEGORY) . '</option>';
                                            }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <input type="submit" name="submit" class="btn btn-success" value="Search">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</form>
</body>
</html>
