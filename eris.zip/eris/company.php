<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project with AOS and Swiper Animations</title>
    
    <!-- Include AOS CSS -->
    <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
    
    <!-- Include Swiper CSS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@9/swiper-bundle.min.css">
    
    <!-- Inline CSS for the Project -->
    <style>

.company-card {
    border: 1px solid #ddd; /* Light gray border for a clean look */
    border-radius: 16px; /* Increase the rounding for a smoother rectangle */
    padding: 20px; /* Maintain padding for proper spacing */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Slightly larger shadow for depth */
    background: #fff; /* Ensure a white background */
    text-align: center; /* Center-align text and content */
    transition: all 0.3s ease-in-out; /* Smooth hover transition */
    margin-bottom: 20px;
    font-family: Arial, sans-serif;
}

.company-card:hover {
    background: linear-gradient(to right, rgba(106, 17, 203, 0.3), rgba(37, 117, 252, 0.3)); /* faint gradient */
    transform: translateY(-8px); /* Lift the card slightly on hover */
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15); /* Add a more pronounced shadow on hover */
}

        .company-card i {
            color: #007bff;
        }
        .comapany-card container {
            text-align: center;
        }
        </style>

    <section id="content">
        <div class="container content">     
        <!-- Service Blcoks -->  
        <div class="row">
            <?php 
                  $sql = "SELECT * FROM `tblcompany`";
                  $mydb->setQuery($sql);
                  $comp = $mydb->loadResultList(); 

                  foreach ($comp as $company ) { 
            ?>
                    <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
                    <div class="company-card">
                        <i class="fa fa-building-o fa-3x mb-3"></i>
                       <h3><?php echo '<a href="'.web_root.'index.php?q=hiring&search='.$company->COMPANYNAME.'">'.$company->COMPANYNAME.'</a>';?></h3>
                        <p>
                            <strong>Address:</strong> <?php echo $company->COMPANYADDRESS; ?><br>
                            <strong>Contact:</strong> <?php echo $company->COMPANYCONTACTNO; ?>
                        </p>
                    </div>
                </div>

            <?php } ?>

 
 
         </div> 
        </div>
    </section>

     <!-- Include AOS JS -->
     <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
    
    <!-- Include Swiper JS -->
    <script src="https://unpkg.com/swiper@9/swiper-bundle.min.js"></script>
    
    <!-- Custom Scripts -->
   
</body>

</html>